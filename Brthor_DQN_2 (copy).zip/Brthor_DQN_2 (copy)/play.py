import gym
from gym.utils.play import play

play(gym.make("Breakout-v0"), zoom=3)