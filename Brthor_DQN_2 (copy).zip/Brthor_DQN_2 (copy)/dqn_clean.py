# see tutorial and explanation
# https://www.youtube.com/watch?v=tsy1mgB7hB0&t=2086s

from torch.nn.modules.conv import Conv2d
from torch.nn.modules.flatten import Flatten

from torch import nn
import torch
import gym
from collections import deque
import itertools
import numpy as np
import torch.nn.functional as F
import matplotlib.pyplot as plt
import random
import os
from torch.utils.tensorboard import SummaryWriter

from pytorch_wrappers import BatchedPytorchFrameStack, PytorchLazyFrames
from pytorch_wrappers import make_atari_deepmind
from baselines_wrappers.dummy_vec_env import DummyVecEnv
from baselines_wrappers.subproc_vec_env import SubprocVecEnv
from baselines_wrappers.monitor import Monitor

import msgpack
from msgpack_numpy import patch as msgpack_numpy_patch
msgpack_numpy_patch()

# Hyperperameters
GAMMA=0.99
BATCH_SIZE=32
BUFFER_SIZE=int(1e6)
MIN_REPLAY_SIZE=50000
EPSILION_START=1.0
EPSILION_END=0.1
EPSILON_DECAY=int(1e6)
NUM_ENVS = 4
TARGET_UPDATE_FREQ=10000 // NUM_ENVS 
LEARNING_RATE = 5e-5
SAVE_PATH = './Brthor_DQN_2/atari_model2.pack'
SAVE_INTERVAL = 1000
LOG_DIR = './Brthor_DQN_2/logs/atari_vanilla'
LOG_INTERVAL = 1000


def nature_cnn(observation_space, depths=(32, 64, 64), final_layer=512):
    n_input_channels = observation_space.shape[0]

    cnn = nn.Sequential(
        nn.Conv2d(n_input_channels, depths[0], kernel_size=8, stride=4),
        nn.ReLU(),
        nn.Conv2d(depths[0], depths[1], kernel_size=4, stride=2),
        nn.ReLU(),
        nn.Conv2d(depths[1], depths[2], kernel_size=3, stride=1),
        nn.ReLU(),
        nn.Flatten())

    # Compute shape by doing one forward pass
    with torch.no_grad():
        n_flatten = cnn(torch.as_tensor(observation_space.sample()[None]).float()).shape[1]

    out = nn.Sequential(cnn, nn.Linear(n_flatten, final_layer), nn.ReLU())

    return out

class CnnNetwork(nn.Module):
    def __init__(self, env):
        super().__init__()

        self.num_actions = env.action_space.n
        conv_net = nature_cnn(env.observation_space)
        self.net = nn.Sequential(conv_net, nn.Linear(512, self.num_actions))

    def forward(self, x):
        return self.net(x)


class FCNetwork(nn.Module):
    def __init__(self, env):
        super().__init__()

        in_features = int(np.prod(env.observation_space.shape))
        self.net = nn.Sequential(
            nn.Flatten(),
            nn.Linear(in_features, 32),
            nn.ReLU(),
            nn.Linear(32, 64),
            nn.ReLU(),
            nn.Linear(64, env.action_space.n)
        )

    def forward(self, x):
        return self.net(x)



class ReplayBuffer:
    def __init__(self, len=BUFFER_SIZE):
        self.memory = deque(maxlen=len)

    def add(self, transition):
        self.memory.append(transition)

    def sample(self, batch_size: int) -> list:
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)



class Agent:

    def __init__(self, env, is_training=True):

        self.env = env
        self.memory = ReplayBuffer()
        self.is_training = is_training
        self.num_actions = env.action_space.n
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        
        # initialize NNs
        self.online_net = CnnNetwork(self.env)
        self.target_net = CnnNetwork(self.env)
        self.online_net = self.online_net.to(self.device)
        self.target_net = self.target_net.to(self.device)

        self.target_net.load_state_dict(self.online_net.state_dict())

        self.optimizer = torch.optim.Adam(self.online_net.parameters(), lr=LEARNING_RATE)

        if self.is_training:
            self.init_replay_buffer()


    def init_replay_buffer(self):

        # initialize replay buffer
        states = self.env.reset()
        for _ in range(MIN_REPLAY_SIZE):
            actions = [self.env.action_space.sample() for _ in range(NUM_ENVS)]
            new_states, rewards, dones, _ = self.env.step(actions)


            for state, action, reward, done, new_state in zip(states, actions, rewards, dones, new_states):


                transition = (state, action, reward, done, new_state)

                self.memory.add(transition) 
                
            states = new_states

    def pick_action(self, step, states):

        if self.is_training:
            epsilon = np.interp(step * NUM_ENVS, [0, EPSILON_DECAY], [EPSILION_START, EPSILION_END])
        else:
            epsilon = EPSILION_END

        states_t = torch.as_tensor(states, dtype=torch.float32, device=self.device)
        q_values = self.online_net(states_t)
        max_q_indices = torch.argmax(q_values, dim=1)
        actions = max_q_indices.detach().tolist()

        # for each env, perform epsilon greedy
        for i in range(len(actions)):
            random_sample = random.random()
            if random_sample <= epsilon:
                actions[i] = random.randint(0, self.num_actions -1)

        return actions
    

    def save(self, save_path):
        params = {k: t.detach().cpu().numpy() for k, t in self.online_net.state_dict().items()}
        params_data = msgpack.dumps(params)
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        with open(save_path, 'wb') as f:
            f.write(params_data)


    def load(self, load_path):
        if not os.path.exists(load_path):
            raise FileNotFoundError(load_path)

        with open(load_path, 'rb') as f:
            params_numpy = msgpack.loads(f.read())
        
        params = {k: torch.as_tensor(v, device=self.device) for k,v in params_numpy.items()}
        self.online_net.load_state_dict(params)


    def learn(self, step):
        # start gradient step
        transitions = self.memory.sample(BATCH_SIZE)

        # Transpose the batch (see https://stackoverflow.com/a/19343/3343043 for detailed explanation). 
        # This converts an array of Transitions to a Transition of arrays. 
        # basically converts array of tuples to list of columns where each element comes from index in tuple
        t2 = list(zip(*transitions))
        states = t2[0]
        actions = np.asarray(t2[1])
        rewards = np.asarray(t2[2])
        dones = np.asarray(t2[3])
        new_states = t2[4]

        if isinstance(states[0], PytorchLazyFrames):
            states = np.stack([o.get_frames() for o in states])
            new_states = np.stack([o.get_frames() for o in new_states])
        else:
            states = np.asanyarray(states)
            new_states = np.asanyarray(new_states)
        
        # convert the transitions into lists and then nd arrays (as quicker to convert ndarray to torch tensor than list)
        # states = np.asarray([t[0] for t in transitions])
        # actions = np.asarray([t[1] for t in transitions])
        # rewards = np.asarray([t[2] for t in transitions])
        # dones = np.asarray([t[3] for t in transitions])

        # new_states = np.asarray([t[4] for t in transitions])

        states_t = torch.as_tensor(states, dtype=torch.float32, device=self.device)
        actions_t = torch.as_tensor(actions, dtype=torch.int64, device=self.device).unsqueeze(-1)
        rewards_t = torch.as_tensor(rewards, dtype=torch.float32, device=self.device).unsqueeze(-1)
        dones_t = torch.as_tensor(dones, dtype=torch.float32, device=self.device).unsqueeze(-1)
        new_states_t = torch.as_tensor(new_states, dtype=torch.float32, device=self.device)


        # Compute Target q values ( using target q network)
        target_q_values = self.target_net(new_states_t)
        max_target_q_values = target_q_values.max(dim=1, keepdim=True)[0]

        # L_i(0_i) = E ~ [{(target q value) - (state q value)}^2]

        # compute target in Bellman equation
        targets = rewards_t + GAMMA * ( 1 - dones_t ) * max_target_q_values

        
        # get the input state q_value of batches (using online qnetwork)
        # very nice trick to gather valuesof the input q_values using the actions_t to index which value to select
        q_values = self.online_net(states_t)
        action_q_values = torch.gather(input=q_values, dim=1, index=actions_t)
        
        # Compute Loss - HUBER loss
        loss = nn.functional.smooth_l1_loss(action_q_values, targets)

        # gradient step
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # update target net every C steps
        if step % TARGET_UPDATE_FREQ == 0:
            self.target_net.load_state_dict(self.online_net.state_dict())



if __name__ == '__main__':

    ################################################################################
    # main training loop
    ################################################################################
    # environment - quick one to run to check if the algo works correctly
    # make_atari_deepmind first creates env but then applies all the preprocessing 
    # steps to the environment from the DQN paper before our agent sees the observation
    # Gym wrappers are a convenient way of doing this
    # need to make into lambda function for the DummyVecEnv
    ENV_NICK_NAME = 'BreakOut'

    make_env = lambda : Monitor(make_atari_deepmind('BreakoutNoFrameskip-v4', scale_values=True), allow_early_resets=True)
    
    vec_env = DummyVecEnv([make_env for _ in range(NUM_ENVS)])
    #env = SubprocVecEnv([make_env for _ in NUM_ENVS])
    env = BatchedPytorchFrameStack(vec_env, k=4)

    print(f'env.observation_space: {env.observation_space}')
    print(f'env.action_space: {env.action_space}')

    agent = Agent(env)
    agent.init_replay_buffer()

    # store rewards accumulated by agent earned in a single episode
    # use this to keep track of the improvement of the agent as it trains
    ep_infos_buffer = deque([], maxlen=100)
    scores = [] # list containing score from each episode

    # init the reward gained from an episode
    episode_count = 0

    # for tensorboard 
    summary_writer = SummaryWriter(LOG_DIR)

    # initialize the max (average) reward
    max_rew_mean = 0

    states = env.reset()


    for step in itertools.count():

        step += 1

        # 1. agent picks an action given the state
        if isinstance(states[0], PytorchLazyFrames):
            act_states = np.stack([o.get_frames() for o in states])
            actions = agent.pick_action(step, act_states)
        else:
            actions = agent.pick_action(step, states)

        # 2. apply the action to the env and get reward, new_state and done

        new_states, rewards, dones, infos = env.step(actions)

        # 3. add newest transition to memory
        for state, action, reward, done, new_state, info in zip(states, actions, rewards, dones, new_states, infos):

            transition = (state, action, reward, done, new_state)
            agent.memory.add(transition)

            # envs auto restart when done so no need to reset explicitly
            if done:
                ep_infos_buffer.append(info['episode'])
                episode_count += 1

        # 4. perform lerning
        agent.learn(step)

        # Update to new_state
        states = new_states
    
        # logging
        if step % LOG_INTERVAL == 0:
            rew_mean = np.mean([e['r'] for e in ep_infos_buffer]) or 0
            len_mean = np.mean([e['l'] for e in ep_infos_buffer]) or 0
            print(f'Episodes [{episode_count}], Step [{step}], Avg Rew: {rew_mean}, Avg Ep Len: {len_mean}')

            summary_writer.add_scalar('AvgRew', rew_mean, global_step=step)
            summary_writer.add_scalar('AvgEpLen', len_mean, global_step=step)
            summary_writer.add_scalar('Episodes', episode_count, global_step=step)
                

        # saving
        if step % SAVE_INTERVAL == 0 and step != 0:
            rew_mean = np.mean([e['r'] for e in ep_infos_buffer]) or 0
            if rew_mean > max_rew_mean:
                max_rew_mean = rew_mean
                print(f'New High Score! {rew_mean}.  Saving model after {step} steps ...')
                agent.save(SAVE_PATH)


    #plot the scores
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plt.plot(np.arange(len(scores)),scores)
    plt.ylabel('Score')
    plt.xlabel('Epsiode #')
    plt.savefig("mygraph.png")
    plt.show()